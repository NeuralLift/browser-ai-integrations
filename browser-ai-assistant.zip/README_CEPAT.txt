# Browser AI Assistant - Quick Start (NeuralLift)

Paket ini berisi Backend (Executable) dan Extension untuk Browser AI Assistant.

## Cara Menjalankan:

### 1. Persiapan Backend
1. Jalankan `run_backend.bat`.
2. Jika baru pertama kali, Anda akan diminta memasukkan **Google Gemini API Key**.
3. Masukkan key-nya, dan sistem akan otomatis membuat file `.env` untuk Anda.
4. JANGAN TUTUP jendela command prompt selama menggunakan asisten.

### 2. Pasang Extension di Browser
1. Buka Google Chrome (atau Edge/Brave).
2. Pergi ke halaman `chrome://extensions`.
3. Aktifkan **Developer mode** (pojok kanan atas).
4. Klik **Load unpacked**.
5. Pilih folder `extension` yang ada di dalam folder ini.

### 3. Mulai Gunakan
1. Buka website apa saja.
2. Klik ikon ekstensi atau buka **Side Panel** di browser.
3. Chat dengan asisten!

---
Dibuat dengan ❤️ oleh NeuralLift
